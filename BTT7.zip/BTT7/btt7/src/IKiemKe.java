public abstract class IKiemKe {

}
