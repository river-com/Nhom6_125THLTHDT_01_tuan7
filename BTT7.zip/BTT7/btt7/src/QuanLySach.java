public abstract class QuanLySach {

}
