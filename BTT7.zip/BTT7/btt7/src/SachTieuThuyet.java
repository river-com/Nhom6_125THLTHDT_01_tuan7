public abstract class SachTieuThuyet {

}
