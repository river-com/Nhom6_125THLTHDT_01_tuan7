public abstract class Sach {
private double giacoban;
private String tenSach;
public Sach(double giacoban, String tenSach){
    this.giacoban=giacoban;
    this.tenSach=tenSach;
}
public void setter(double giacoban){
    this.giacoban=giacoban;
}
public double getter (){
    return giacoban;
}
public void set_tenSach(String tenSach){
    this.tenSach=tenSach;
}
public String get_tenSach(){
    return tenSach;
}
public abstract double tinhgiaban();
}
